package com.example.quizapp


class Question(
        val questionId: Int,
        val trueAnswer: Boolean
)